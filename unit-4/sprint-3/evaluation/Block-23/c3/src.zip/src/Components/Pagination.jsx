function createArrayOfSize(n) {
  return new Array(n).fill(0);
}
// totalPages
// currentPage
// handlePageChange
function Pagination({totalPages,currentPage,handlePageChange}) {
  console.log(createArrayOfSize(totalPages))
  
  
  let pages = createArrayOfSize(totalPages).map((_,a) => {
  return <button key={Date.Now} data-testid="page-btn" onClick={()=>handlePageChange(a+1)} disabled={currentPage==a+1}>{a+1}</button>;
  });
  return <div>{pages}</div>;
}

export default Pagination;
