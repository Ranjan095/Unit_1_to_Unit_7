import AllRoutes from "./Routes/AllRoutes";
import "./styles.css";
import Home from "./Routes/Home";

export default function App() {
  return (
    <div className="App">
      <AllRoutes />
    </div>
  );
}

// authentication: reqres.in
//
